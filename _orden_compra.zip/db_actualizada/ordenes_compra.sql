-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 06, 2023 at 12:07 AM
-- Server version: 8.0.30
-- PHP Version: 7.4.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ordenes_compra`
--

-- --------------------------------------------------------

--
-- Table structure for table `item_list`
--

CREATE TABLE `item_list` (
  `id` int NOT NULL,
  `product_key` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `supplier_id` int NOT NULL,
  `quantity` int NOT NULL,
  `unit` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci NOT NULL,
  `delivery_time` int NOT NULL,
  `department` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `art` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `item_list`
--

INSERT INTO `item_list` (`id`, `product_key`, `supplier_id`, `quantity`, `unit`, `description`, `delivery_time`, `department`, `art`, `date_created`) VALUES
(2, 'Crema para cara Delia Azul', 0, 0, '0', 'Crema de limpieza profunda con suero facial y nutrientes.', 0, '', '', '2021-09-08 10:21:42'),
(3, 'Camiseta Baluga Personalizables', 0, 0, '0', 'Son las mejores camisetas con las mejores telas del mercado a precios muy econ&oacute;micas', 0, '', '', '2021-09-08 10:22:10'),
(4, 'Tapabocas Endistol 1105', 0, 0, '0', 'Tapabocas de alta calidad, con registro INVIMA 13241 Apta para uso m&eacute;dico', 0, '', '', '2021-09-09 15:21:46'),
(6, 'Tubo PPR', 0, 0, '0', 'PPRR 111', 0, '', '', '2023-06-07 21:47:38'),
(8, 'Coca Cola ', 0, 0, '0', '3litros', 0, '', '', '2023-06-27 19:42:17'),
(9, 'Papas Fritas', 0, 0, '0', 'Familiar ', 0, '', '', '2023-06-27 19:42:38'),
(11, 'Salsas Fruco ', 0, 0, '0', '', 0, '', '', '2023-06-27 19:43:26'),
(12, 'laptop', 0, 0, '0', 'laptop', 0, '', '', '2023-07-14 17:52:12'),
(13, 'sssss', 0, 0, '0', 'vdfdwd', 0, '', '', '2023-08-03 21:51:53'),
(14, 'prueba', 0, 1, '1', 'kg', 2, '', '', '2023-08-22 21:35:31'),
(15, 'ass', 0, 1, '1', 'kg', 1, '001', '001', '2023-08-22 21:41:43'),
(16, 'prueba clave', 0, 1, '1', 'producto en kg', 10, '002', '010', '2023-08-22 22:34:41'),
(17, 'solución de limpieza', 6, 2, 'caja', '(con 9 litros)', 2, 'Producción', '001', '2023-08-26 17:02:32'),
(18, 'xxx', 3, 2, 'xxx', 'xxx', 2, 'xxx', 'xxxx', '2023-08-26 17:54:02');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `po_id` int NOT NULL,
  `item_id` int NOT NULL,
  `unit` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `unit_price` float NOT NULL,
  `quantity` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`po_id`, `item_id`, `unit`, `unit_price`, `quantity`) VALUES
(1, 2, 'pcs', 17999.9, 6),
(1, 2, 'caja', 38, 1),
(3, 4, '12', 25000, 50),
(10, 2, '2', 12, 12),
(27, 4, '1', 10, 1),
(28, 8, '4758', 8200, 4),
(28, 9, '7895', 7600, 2),
(28, 11, '7955', 1800, 2),
(35, 12, '1', 12000, 1),
(40, 2, '', 6000, 1),
(40, 11, '', 500, 1),
(17, 2, '1', 123, 12),
(17, 2, '2', 120, 4),
(46, 8, 'PIEZAS', 0, 28),
(46, 6, 'PIEZAS', 0, 4),
(23, 3, '1', 100, 1),
(34, 9, 'niu', 15, 1),
(41, 9, '2', 20, 1),
(48, 3, '10', 100, 1),
(48, 11, '22', 100, 2),
(44, 9, '', 4500, 1),
(49, 3, 'ss', 100, 1);

-- --------------------------------------------------------

--
-- Table structure for table `postal_codes`
--

CREATE TABLE `postal_codes` (
  `id` int NOT NULL,
  `postal_code` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `postal_codes`
--

INSERT INTO `postal_codes` (`id`, `postal_code`) VALUES
(1, 123456),
(2, 123457),
(3, 12345),
(4, 1011546),
(5, 551400),
(6, 87777777);

-- --------------------------------------------------------

--
-- Table structure for table `po_list`
--

CREATE TABLE `po_list` (
  `id` int NOT NULL,
  `po_no` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `supplier_id` int NOT NULL,
  `discount_percentage` float NOT NULL,
  `discount_amount` float NOT NULL,
  `tax_percentage` float NOT NULL,
  `tax_amount` float NOT NULL,
  `notes` text COLLATE utf8mb4_general_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=pending, 1= Approved, 2 = Denied',
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `po_list`
--

INSERT INTO `po_list` (`id`, `po_no`, `supplier_id`, `discount_percentage`, `discount_amount`, `tax_percentage`, `tax_amount`, `notes`, `status`, `date_created`, `date_updated`) VALUES
(1, 'PO-94619964639', 1, 2, 5160.75, 12, 30964.5, 'Sample Purchase Order Only', 1, '2021-09-08 15:20:57', '2023-05-03 18:58:11'),
(3, 'PO-61965473198', 1, 0, 0, 12, 213252, 'Se va a realizar el pago contra entrega', 1, '2021-09-09 15:24:37', '2023-05-16 21:09:34'),
(7, 'PO-67454584574', 1, 0, 0, 16, 40, '', 0, '2023-05-17 17:02:48', '2023-05-31 22:52:54'),
(10, 'PO-09432186525', 1, 0, 0, 18, 60.84, '', 1, '2023-05-29 03:23:18', '2023-06-15 17:26:58'),
(11, 'PO-82593231302', 1, 0, 0, 16, 55.2, '', 1, '2023-05-31 22:51:59', '2023-06-15 21:36:37'),
(17, 'PO-35840355952', 1, 16, 312.96, 0, 0, 'Prueba de OC', 1, '2023-06-06 16:31:31', '2023-08-04 22:13:17'),
(18, 'PO-47332073333', 1, 0, 0, 0, 0, '', 1, '2023-06-07 00:41:13', '2023-06-07 00:41:30'),
(23, 'PO-02760910927', 1, 0, 0, 0, 0, '', 1, '2023-06-09 21:10:24', NULL),
(27, 'PO-16689075766', 3, 0, 0, 16, 1.6, '', 0, '2023-06-20 19:25:47', '2023-06-22 20:44:57'),
(28, 'PO-03257384409', 6, 100, 60600, 9, 5454, 'Factura # PO-03257384409 Pagada por Gerencia\r\nPendiente el envio', 1, '2023-06-27 19:50:10', '2023-06-27 20:03:11'),
(29, 'PO-48400613430', 6, 0, 0, 0, 0, '', 0, '2023-06-29 22:03:43', NULL),
(30, 'PO-41209391679', 3, 0, 0, 0, 0, 'Favor de autorizar', 1, '2023-06-30 17:27:36', NULL),
(31, 'PO-36046287855', 8, 0, 0, 16, 6.4, '', 2, '2023-07-10 23:11:31', '2023-08-13 03:33:07'),
(32, 'PO-87608188367', 6, 0, 0, 0, 0, '', 0, '2023-07-11 21:41:31', NULL),
(33, '1', 1, 0, 0, 0, 0, '', 0, '2023-07-11 21:42:26', NULL),
(34, 'PO-62594359926', 1, 0, 0, 12, 1.8, 'uso de bodega', 0, '2023-07-14 17:49:01', '2023-08-13 03:34:38'),
(35, 'PO-13841426938', 8, 0, 0, 12, 1440, 'para uso de bodega', 1, '2023-07-14 17:52:54', '2023-07-14 17:55:44'),
(40, 'PO-86991949934', 1, 0, 0, 0, 0, '', 1, '2023-07-17 00:59:03', NULL),
(41, 'PO-00300936529', 8, 0, 0, 0, 0, '', 1, '2023-07-25 21:26:44', '2023-08-13 03:40:21'),
(42, 'PO-29109224296', 8, 0, 0, 0, 0, '', 0, '2023-07-27 20:53:43', NULL),
(43, '123', 8, 0, 0, 13, 161905, '', 0, '2023-08-03 21:56:47', NULL),
(44, 'PO-45114856767', 8, 10, 450, 10, 450, 'test', 0, '2023-08-07 21:44:40', '2023-08-24 22:24:08'),
(45, 'PO-36791541855', 6, 0, 0, 0, 0, 'PRUEBA 2', 0, '2023-08-08 17:26:51', '2023-08-08 17:29:04'),
(46, 'PO-32567746719', 3, 0, 0, 0, 0, 'PRUEBA 2', 0, '2023-08-08 17:33:22', NULL),
(47, 'PO-56168142235', 6, 10, 10, 10, 10, 'esta es una prueba', 1, '2023-08-22 20:20:43', NULL),
(48, 'PO-54329951726', 6, 10, 30, 10, 30, '', 1, '2023-08-23 23:39:02', '2023-08-24 00:14:16'),
(49, 'PO-20350123872', 6, 10, 10, 10, 10, 'asdasd', 1, '2023-08-27 10:55:45', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `req_items`
--

CREATE TABLE `req_items` (
  `id` int NOT NULL,
  `req_id` int NOT NULL,
  `item_id` int NOT NULL,
  `unit_price` int NOT NULL,
  `quantity` int NOT NULL,
  `supplier_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `req_items`
--

INSERT INTO `req_items` (`id`, `req_id`, `item_id`, `unit_price`, `quantity`, `supplier_id`) VALUES
(68, 10, 18, 100, 2, 3),
(69, 10, 17, 50, 2, 6);

-- --------------------------------------------------------

--
-- Table structure for table `req_list`
--

CREATE TABLE `req_list` (
  `id` int NOT NULL,
  `date_created` date NOT NULL,
  `date_update` datetime DEFAULT CURRENT_TIMESTAMP,
  `author_name` varchar(100) NOT NULL,
  `credit_status` int NOT NULL,
  `type_order` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `counted` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `iva_percentage` int NOT NULL,
  `iva_amount` int NOT NULL,
  `isr_percentage` int NOT NULL,
  `isr_amount` int NOT NULL,
  `observation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `department` varchar(100) NOT NULL,
  `invoice` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `way_pay` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `client_invoice` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `client_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `bank` varchar(100) NOT NULL,
  `client_key` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `client_account_num` int NOT NULL,
  `client_card_num` int NOT NULL,
  `branch_office` varchar(100) NOT NULL,
  `pr_no` varchar(100) NOT NULL,
  `contact_client` varchar(50) NOT NULL,
  `email_client` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `req_list`
--

INSERT INTO `req_list` (`id`, `date_created`, `date_update`, `author_name`, `credit_status`, `type_order`, `counted`, `iva_percentage`, `iva_amount`, `isr_percentage`, `isr_amount`, `observation`, `department`, `invoice`, `way_pay`, `client_invoice`, `client_name`, `bank`, `client_key`, `client_account_num`, `client_card_num`, `branch_office`, `pr_no`, `contact_client`, `email_client`) VALUES
(10, '2023-08-28', '2023-08-28 01:06:32', 'alisson', 1, 'pedidp prueba', 'N/A', 10, 30, 5, 15, 'prueba', 'weswes', 'N/A', 'efectivo', 'N/A', 'fulanito', 'bbc', '123456', 123344, 987456, 'centro', 'REQ-08726430560', '32111111111111', 'EXAMPLE@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `supplier_list`
--

CREATE TABLE `supplier_list` (
  `id` int NOT NULL,
  `name` varchar(250) COLLATE utf8mb4_general_ci NOT NULL,
  `business_name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `postal_code_id` int NOT NULL,
  `suburb` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `town_hall` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `contact_sold` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `contact_invoice` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `contact_pay` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `discount` int NOT NULL,
  `type_person` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `credit` int NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_general_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier_list`
--

INSERT INTO `supplier_list` (`id`, `name`, `business_name`, `postal_code_id`, `suburb`, `town_hall`, `contact_sold`, `contact_invoice`, `contact_pay`, `discount`, `type_person`, `credit`, `email`, `date_created`) VALUES
(1, 'Pesas y Pesas García', '', 0, '', '', 'Rafael Pérez', '3122874659', '', 0, '', 0, 'rperez@cweb.com', '2021-09-08 09:46:45'),
(3, 'Tapabocas  Capabol', '', 0, '', '', '3152587412', '3012584651', '', 0, '', 0, 'admin@tapacapabol.com', '2021-09-09 15:20:32'),
(6, 'Licores JL', '', 0, '', '', 'Santiago Lopez Ramirez', '3028580166', '', 0, '', 0, 'santiago@gerente.com', '2023-06-27 19:46:59'),
(8, 'INTCOMEX DE GUATEMALA, S.A.', 'INTCOMEX DE GUATEMALA, S.A.', 3, 'colonia nueva', 'ejemplo alcaldia', 'EDGAR QUINTEROS', 'jc 3222222', '3212222', 0, 'fisica', 0, 'equinteros@gmail.com', '2023-07-14 17:51:52'),
(12, 'Prueba inical', 'PR INICIAL', 3, 'colonia 1', 'alcaldia 1', 'daniel: 555555', 'xxx: 55555', 'llll: 888888', 25, 'fisica', 0, 'aaaa@gmail.com', '2023-08-23 02:57:18');

-- --------------------------------------------------------

--
-- Table structure for table `system_info`
--

CREATE TABLE `system_info` (
  `id` int NOT NULL,
  `meta_field` text COLLATE utf8mb4_general_ci NOT NULL,
  `meta_value` text COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `system_info`
--

INSERT INTO `system_info` (`id`, `meta_field`, `meta_value`) VALUES
(1, 'name', ''),
(6, 'short_name', 'GCO'),
(11, 'logo', 'uploads/1693957380_ICONO ALVARTIS.jpg'),
(13, 'user_avatar', 'uploads/user_avatar.jpg'),
(14, 'cover', 'uploads/1693957380_fondo3.jpg'),
(15, 'company_name', 'ALVARTIS PHARMA S.A. DE C.V.'),
(16, 'company_email', 'hola@gestiondeordenes.com'),
(17, 'company_address', 'Calle 78 N 24 32'),
(18, 'company_name', 'ALVARTIS PHARMA S.A. DE C.V.'),
(19, 'company_email', 'hola@gestiondeordenes.com'),
(20, 'company_address', 'Calle 78 N 24 32'),
(21, 'cover', 'uploads/1693957380_fondo3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tax_records`
--

CREATE TABLE `tax_records` (
  `id` int NOT NULL,
  `req_id` int NOT NULL,
  `name_file` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tax_records`
--

INSERT INTO `tax_records` (`id`, `req_id`, `name_file`) VALUES
(10, 6, '64ec2f5074df7.pdf'),
(11, 7, '64ec312089904.pdf'),
(12, 7, '64ec31208a79f.pdf'),
(14, 9, '64ec35c6ba068.pdf'),
(16, 10, '64ec3968dd7ed.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `firstname` varchar(250) COLLATE utf8mb4_general_ci NOT NULL,
  `lastname` varchar(250) COLLATE utf8mb4_general_ci NOT NULL,
  `username` text COLLATE utf8mb4_general_ci NOT NULL,
  `password` text COLLATE utf8mb4_general_ci NOT NULL,
  `avatar` text COLLATE utf8mb4_general_ci,
  `last_login` datetime DEFAULT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '0',
  `date_added` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `username`, `password`, `avatar`, `last_login`, `type`, `date_added`, `date_updated`) VALUES
(1, 'Mauricio', 'Sevilla', 'configuroweb', '4b67deeb9aba04a5b54632ad19934f26', 'uploads/1631295840_logo youtube.png', NULL, 1, '2021-01-20 14:02:37', '2021-09-10 12:44:39'),
(3, 'Juan', 'Operador', 'joperador', '4b67deeb9aba04a5b54632ad19934f26', 'uploads/1631219220_avatar1.jpg', NULL, 2, '2021-09-07 15:20:40', '2021-09-09 15:27:37');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `item_list`
--
ALTER TABLE `item_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD KEY `po_id` (`po_id`),
  ADD KEY `item_no` (`item_id`);

--
-- Indexes for table `postal_codes`
--
ALTER TABLE `postal_codes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `po_list`
--
ALTER TABLE `po_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `supplier_id` (`supplier_id`);

--
-- Indexes for table `req_items`
--
ALTER TABLE `req_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `req_id` (`req_id`);

--
-- Indexes for table `req_list`
--
ALTER TABLE `req_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `supplier_list`
--
ALTER TABLE `supplier_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_info`
--
ALTER TABLE `system_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tax_records`
--
ALTER TABLE `tax_records`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `item_list`
--
ALTER TABLE `item_list`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `postal_codes`
--
ALTER TABLE `postal_codes`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `po_list`
--
ALTER TABLE `po_list`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `req_items`
--
ALTER TABLE `req_items`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `req_list`
--
ALTER TABLE `req_list`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `supplier_list`
--
ALTER TABLE `supplier_list`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `system_info`
--
ALTER TABLE `system_info`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tax_records`
--
ALTER TABLE `tax_records`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `item_list` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`po_id`) REFERENCES `po_list` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `po_list`
--
ALTER TABLE `po_list`
  ADD CONSTRAINT `po_list_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `supplier_list` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `req_items`
--
ALTER TABLE `req_items`
  ADD CONSTRAINT `req_items_ibfk_1` FOREIGN KEY (`req_id`) REFERENCES `req_list` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
